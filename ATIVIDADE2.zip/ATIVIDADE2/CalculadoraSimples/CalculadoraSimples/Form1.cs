﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraSimples
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }

        private void btnMais_Click(object sender, EventArgs e)
        {
            double Numero1, Numero2, Resultado;
            if ((double.TryParse(txtNumero1.Text, out Numero1)) &&
                (double.TryParse(txtNumero2.Text, out Numero2)))
            {
                Resultado = Numero1 + Numero2;
                txtResultado.Text = Resultado.ToString();
            }
            else
                MessageBox.Show("Números Inválidos!!!");
        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            double Numero1, Numero2, Resultado;
            if ((double.TryParse(txtNumero1.Text, out Numero1)) &&
                (double.TryParse(txtNumero2.Text, out Numero2)))
            {
                Resultado = Numero1 - Numero2;
                txtResultado.Text = Resultado.ToString();
            }
            else
                MessageBox.Show("Números Inválidos!!!");
        }

        private void btnVezes_Click(object sender, EventArgs e)
        {
            double Numero1, Numero2, Resultado;
            if ((double.TryParse(txtNumero1.Text, out Numero1)) &&
                (double.TryParse(txtNumero2.Text, out Numero2)))
            {
                Resultado = Numero1 * Numero2;
                txtResultado.Text = Resultado.ToString();
            }
            else
                MessageBox.Show("Números Inválidos!!!");
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            double Numero1, Numero2, Resultado;
            if ((double.TryParse(txtNumero1.Text, out Numero1)) &&
                (double.TryParse(txtNumero2.Text, out Numero2)))
            {
                if (Numero2 != 0)
                {
                    Resultado = Numero1 / Numero2;
                    txtResultado.Text = Resultado.ToString();
                }
                else
                    MessageBox.Show("Digite valor diferente de 0!!!");
            }
            else
                MessageBox.Show("Números Inválidos!!!");
        }
    }
}
