﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace ATIVIDADE8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercício1_Click(object sender, EventArgs e)
        {
            double[] vetor = new double[20];
            string auxiliar;

            for (var i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite o número " + (i + 1).ToString());

                if(!(double.TryParse(auxiliar, out vetor[i])))
                {
                    MessageBox.Show("Número Inválido!!!");
                    i--;
                }
            }
            auxiliar = "";
            for(var i = vetor.Length - 1; i >= 0; i--)
                auxiliar += vetor[i].ToString() + "\n";

            MessageBox.Show(auxiliar);

        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            double[] vetor = new double[20];
            string auxiliar;

            for (var i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite o número " + (i + 1).ToString());

                if (!(double.TryParse(auxiliar, out vetor[i])))
                {
                    MessageBox.Show("Número Inválido!!!");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
            
            foreach (double d in (vetor))
            {
                auxiliar = auxiliar + d.ToString();
            }

            MessageBox.Show(auxiliar + "\n");
        }

        private void btnExercício3_Click(object sender, EventArgs e)
        {
            double[] qtdeMercadoriavendida = new double[10];
            double[] valor = new double[10];
            double[] faturamento = new double[10];

            int cont;
            double faturamentoMensal;
            string auxiliar1, auxiliar2;

            faturamentoMensal = 0;

            // Mercadorias vendidas
            for (cont = 0; cont < 10; cont++)
            {
                auxiliar1 = Interaction.InputBox("Digite a quantidade de mercadorias vendidas " + (cont + 1).ToString());
                qtdeMercadoriavendida[cont] = Convert.ToDouble(auxiliar1);
            }

            // Preço das mercadorias
            for (cont = 0; cont < 10; cont++)
            {
                auxiliar2 = Interaction.InputBox("Digite o valor da mercadoria " + (cont + 1).ToString());
                valor[cont] = Convert.ToDouble(auxiliar2);
            }

            // Faturamento mensal
            for (cont = 0; cont < 10; cont++)
            {
                faturamento[cont] = qtdeMercadoriavendida[cont] * valor[cont];
                faturamentoMensal = faturamentoMensal + faturamento[cont];
            }
            MessageBox.Show("O faturamento mensal do armazem é: " + faturamentoMensal);
        }

        private void btnExercício4_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Danice", "Junior", "Leonardo", "José", "Nelma", "Toddy" };
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
        }

        private void btnExercício5_Click(object sender, EventArgs e)
        {
            ArrayList nomes = new ArrayList();
            nomes.Add("Ana");
            nomes.Add("André");
            nomes.Add("Débora");
            nomes.Add("Fátima");
            nomes.Add("João");
            nomes.Add("Janete");
            nomes.Add("Otávio");
            nomes.Add("Marcelo");
            nomes.Add("Pedro");
            nomes.Add("Thais");

            nomes.Remove("Otávio");

            foreach (string item in nomes)
            {
                MessageBox.Show(item);
            }
        }

        private void btnExercício6_Click(object sender, EventArgs e)
        {
            int[,] arrInt = new int[,] { { 0, 10, 8, 6 }, { 1, 8, 9, 10 }, { 2, 7, 5, 6 }, { 3, 1, 2, 3 }, { 4, 7, 2, 3 }, { 5, 1, 8, 10 }, { 6, 7, 2, 6 }, { 7, 1, 4, 3 }, { 8, 1, 2, 7 }, { 9, 10, 9, 3 }, { 10, 2, 2, 3 }, { 11, 5, 6, 7 }, { 12, 9, 7, 5 }, { 13, 10, 10, 10 }, { 14, 4, 2, 3 }, { 15, 1, 2, 3 }, { 16, 2, 2, 10 }, { 17, 7, 9, 10 }, { 18, 6, 2, 3 }, { 19, 4, 5, 4 }, { 20, 8, 8, 8 } };
            double[] media = new double[7];
            int [] soma = new int[7];
            int aux = 0;

            int cont, cont2;

            for (cont = 0; cont < 7; cont++)
            {
                for (cont2 = 0; cont2 < 3; cont2++)
                {
                    soma[cont] = soma[aux] + arrInt[cont, cont2 + 1];
                    aux++;
                }
                media[cont] = soma[cont] / 3;
                MessageBox.Show("\nA media de " + (cont + 1) + " e: " + media[cont]);
            }
        }
    }
}
