﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PesoIdeal3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPesoAtual.Clear();
            mskbxAltura.Clear();
        }

        private void Sair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double Altura, PesoAtual;
            double PesoIdeal;
            if ((double.TryParse(mskbxAltura.Text, out Altura)) &&
                (double.TryParse(mskbxPesoAtual.Text, out PesoAtual)))
            {
                if (rbtnFeminino.Checked)
                {
                    PesoIdeal = (62.1 * Altura) - 44.7;
                    if (PesoAtual > PesoIdeal)
                        MessageBox.Show("Regime Obrigatório Já");
                    if (PesoAtual < PesoIdeal)
                        MessageBox.Show("Coma bastante massas e doces");
                    if (PesoAtual == PesoIdeal)
                        MessageBox.Show("Você está com o peso ideal");
                }
                if (rbtnMasculino.Checked)
                {
                    PesoIdeal = (72.7 * Altura) - 58;
                    if (PesoAtual > PesoIdeal)
                        MessageBox.Show("Regime Obrigatório Já");
                    if (PesoAtual < PesoIdeal)
                        MessageBox.Show("Coma bastante massas e doces");
                    if (PesoAtual == PesoIdeal)
                        MessageBox.Show("Você está com o peso ideal");
                }
            }
        }
    }
}
