﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATIVIDADE7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnNumeroBranco_Click(object sender, EventArgs e)
        {
            int cont, contador;
            contador = 0;
            for (cont = 0; cont <= 100; cont++)
            {
                if (Char.IsWhiteSpace(rchbxTexto.Text, cont))
                {
                    contador++;
                }
            }
            MessageBox.Show("O total de espaços em branco é: " + contador);
        }

        private void btnNumeroR_Click(object sender, EventArgs e)
        {
            int cont, contador;
            contador = 0;
            do
            {
                if (Char.ToUpper(rchbxTexto.Text, cont) = 'R')
                {
                    contador++;
                }
            } while (cont = 0; cont <= 100; cont++);
            MessageBox.Show("O total de R's é: " + contador);
        }

        private void btnNumeroPares_Click(object sender, EventArgs e)
        {
            int cont, contador;
            contador = 0;

            RichTextBox rchbxTexto = new System.Windows.Forms.RichTextBox();

            try { rchbxTexto.Text.ToUpper(); }
            catch
            {
                for (cont = 0; cont <= 99; cont++)
                {
                    if (rchbxTexto[cont] == rchbxTexto[cont + 1])
                    {
                        contador++;
                    }
                }
                MessageBox.Show("O total de espaços em branco é: " + contador);
            }
        }

        private void btnNumeroH_Click(object sender, EventArgs e)
        {
            int cont, NumeroN, H;
            H = 0;
            if (int.TryParse(txtNumeroN.Text, out NumeroN))

            for (cont = 1; cont <= NumeroN; cont++)
            {
                H = H + (1 / NumeroN);
            }
            MessageBox.Show("O valor de H equivale à: " + H);
        }

        private void btnPalindromo_Click(object sender, EventArgs e)
        {
            string texto;
            rchbxTexto.Text = rchbxTexto.Text.ToUpper();
            texto = rchbxTexto.Text.Trim();
            char[] arrayTexto = texto.ToCharArray();
            Array.Reverse(arrayTexto);
            if (arrayTexto = texto)
                MessageBox.Show("O texto é palíndromo");
            else
                MessageBox.Show("O texto não é palíndromo");
        }

        private void txtSalarioBruto_TextChanged(object sender, EventArgs e)
        {
            int Producao, B, C, D;
            double SalarioBruto, Gratificacao, Salario;

            if ((double.TryParse(txtSalarioBruto.Text, out SalarioBruto)) &&
                (double.TryParse(txtGratificacao.Text, out Gratificacao)) &&
                (double.TryParse(txtSalario.Text, out Salario)) &&
                (int.TryParse(txtProducao.Text, out Producao)))
            {
                if (Producao >= 100)
                    B = 1;
                else
                    B = 0;
                if (Producao >= 120)
                    C = 1;
                else
                    C = 0; 
                if (Producao >= 150)
                    D = 1;
                else
                    D = 0;
                SalarioBruto = Salario + Salario * (0.05 * B + 0.1 * C + 0.1 * D);
                if (SalarioBruto > 7000 && Producao < 150 || Gratificacao == 0)
                    MessageBox.Show("ERRO!!! Restrição nos dados fornecidos");
                else
                    MessageBox.Show("O salário bruto de " + txtNome + ", " + txtCargo + ", cujo numero de inscrição é " + txtNumeroInscricao + ": R$ " + SalarioBruto);
            }
        }
    }
}
