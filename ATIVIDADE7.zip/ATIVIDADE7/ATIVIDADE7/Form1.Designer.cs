﻿namespace ATIVIDADE7
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchbxTexto = new System.Windows.Forms.RichTextBox();
            this.btnNumeroBranco = new System.Windows.Forms.Button();
            this.btnNumeroR = new System.Windows.Forms.Button();
            this.btnNumeroPares = new System.Windows.Forms.Button();
            this.txtNumeroN = new System.Windows.Forms.TextBox();
            this.lblNumeroN = new System.Windows.Forms.Label();
            this.btnNumeroH = new System.Windows.Forms.Button();
            this.btnPalindromo = new System.Windows.Forms.Button();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblCargo = new System.Windows.Forms.Label();
            this.lblNumeroInscricao = new System.Windows.Forms.Label();
            this.lblProdução = new System.Windows.Forms.Label();
            this.lblSalario = new System.Windows.Forms.Label();
            this.lblGratificação = new System.Windows.Forms.Label();
            this.lblSalarioBruto = new System.Windows.Forms.Label();
            this.txtNumeroInscricao = new System.Windows.Forms.TextBox();
            this.txtProducao = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.MaskedTextBox();
            this.txtGratificacao = new System.Windows.Forms.MaskedTextBox();
            this.txtCargo = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalarioBruto = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // rchbxTexto
            // 
            this.rchbxTexto.Location = new System.Drawing.Point(12, 12);
            this.rchbxTexto.MaxLength = 100;
            this.rchbxTexto.Name = "rchbxTexto";
            this.rchbxTexto.Size = new System.Drawing.Size(248, 108);
            this.rchbxTexto.TabIndex = 0;
            this.rchbxTexto.Text = "";
            // 
            // btnNumeroBranco
            // 
            this.btnNumeroBranco.Location = new System.Drawing.Point(58, 143);
            this.btnNumeroBranco.Name = "btnNumeroBranco";
            this.btnNumeroBranco.Size = new System.Drawing.Size(157, 23);
            this.btnNumeroBranco.TabIndex = 1;
            this.btnNumeroBranco.Text = "Total de Espaços em Branco";
            this.btnNumeroBranco.UseVisualStyleBackColor = true;
            this.btnNumeroBranco.Click += new System.EventHandler(this.btnNumeroBranco_Click);
            // 
            // btnNumeroR
            // 
            this.btnNumeroR.Location = new System.Drawing.Point(58, 172);
            this.btnNumeroR.Name = "btnNumeroR";
            this.btnNumeroR.Size = new System.Drawing.Size(157, 23);
            this.btnNumeroR.TabIndex = 2;
            this.btnNumeroR.Text = "Número de vezes que aparece a letra \"R\"";
            this.btnNumeroR.UseVisualStyleBackColor = true;
            this.btnNumeroR.Click += new System.EventHandler(this.btnNumeroR_Click);
            // 
            // btnNumeroPares
            // 
            this.btnNumeroPares.Location = new System.Drawing.Point(58, 201);
            this.btnNumeroPares.Name = "btnNumeroPares";
            this.btnNumeroPares.Size = new System.Drawing.Size(157, 23);
            this.btnNumeroPares.TabIndex = 3;
            this.btnNumeroPares.Text = "Par de Letras";
            this.btnNumeroPares.UseVisualStyleBackColor = true;
            this.btnNumeroPares.Click += new System.EventHandler(this.btnNumeroPares_Click);
            // 
            // txtNumeroN
            // 
            this.txtNumeroN.Location = new System.Drawing.Point(147, 298);
            this.txtNumeroN.Name = "txtNumeroN";
            this.txtNumeroN.Size = new System.Drawing.Size(100, 20);
            this.txtNumeroN.TabIndex = 4;
            // 
            // lblNumeroN
            // 
            this.lblNumeroN.AutoSize = true;
            this.lblNumeroN.Location = new System.Drawing.Point(21, 301);
            this.lblNumeroN.Name = "lblNumeroN";
            this.lblNumeroN.Size = new System.Drawing.Size(104, 13);
            this.lblNumeroN.TabIndex = 5;
            this.lblNumeroN.Text = "Forneça o número N";
            // 
            // btnNumeroH
            // 
            this.btnNumeroH.Location = new System.Drawing.Point(79, 333);
            this.btnNumeroH.Name = "btnNumeroH";
            this.btnNumeroH.Size = new System.Drawing.Size(108, 23);
            this.btnNumeroH.TabIndex = 6;
            this.btnNumeroH.Text = "Gerar Número H";
            this.btnNumeroH.UseVisualStyleBackColor = true;
            this.btnNumeroH.Click += new System.EventHandler(this.btnNumeroH_Click);
            // 
            // btnPalindromo
            // 
            this.btnPalindromo.Location = new System.Drawing.Point(58, 230);
            this.btnPalindromo.Name = "btnPalindromo";
            this.btnPalindromo.Size = new System.Drawing.Size(157, 23);
            this.btnPalindromo.TabIndex = 7;
            this.btnPalindromo.Text = "Verificar se é Palíndromo";
            this.btnPalindromo.UseVisualStyleBackColor = true;
            this.btnPalindromo.Click += new System.EventHandler(this.btnPalindromo_Click);
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(334, 68);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(35, 13);
            this.lblNome.TabIndex = 8;
            this.lblNome.Text = "Nome";
            // 
            // lblCargo
            // 
            this.lblCargo.AutoSize = true;
            this.lblCargo.Location = new System.Drawing.Point(334, 93);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(35, 13);
            this.lblCargo.TabIndex = 9;
            this.lblCargo.Text = "Cargo";
            // 
            // lblNumeroInscricao
            // 
            this.lblNumeroInscricao.AutoSize = true;
            this.lblNumeroInscricao.Location = new System.Drawing.Point(334, 118);
            this.lblNumeroInscricao.Name = "lblNumeroInscricao";
            this.lblNumeroInscricao.Size = new System.Drawing.Size(105, 13);
            this.lblNumeroInscricao.TabIndex = 10;
            this.lblNumeroInscricao.Text = "Número de Inscrição";
            // 
            // lblProdução
            // 
            this.lblProdução.AutoSize = true;
            this.lblProdução.Location = new System.Drawing.Point(334, 143);
            this.lblProdução.Name = "lblProdução";
            this.lblProdução.Size = new System.Drawing.Size(53, 13);
            this.lblProdução.TabIndex = 11;
            this.lblProdução.Text = "Produção";
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Location = new System.Drawing.Point(334, 172);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(39, 13);
            this.lblSalario.TabIndex = 12;
            this.lblSalario.Text = "Salário";
            // 
            // lblGratificação
            // 
            this.lblGratificação.AutoSize = true;
            this.lblGratificação.Location = new System.Drawing.Point(334, 201);
            this.lblGratificação.Name = "lblGratificação";
            this.lblGratificação.Size = new System.Drawing.Size(64, 13);
            this.lblGratificação.TabIndex = 13;
            this.lblGratificação.Text = "Gratificação";
            // 
            // lblSalarioBruto
            // 
            this.lblSalarioBruto.AutoSize = true;
            this.lblSalarioBruto.Location = new System.Drawing.Point(334, 280);
            this.lblSalarioBruto.Name = "lblSalarioBruto";
            this.lblSalarioBruto.Size = new System.Drawing.Size(67, 13);
            this.lblSalarioBruto.TabIndex = 14;
            this.lblSalarioBruto.Text = "Salário Bruto";
            // 
            // txtNumeroInscricao
            // 
            this.txtNumeroInscricao.Location = new System.Drawing.Point(457, 111);
            this.txtNumeroInscricao.Name = "txtNumeroInscricao";
            this.txtNumeroInscricao.Size = new System.Drawing.Size(100, 20);
            this.txtNumeroInscricao.TabIndex = 15;
            // 
            // txtProducao
            // 
            this.txtProducao.Location = new System.Drawing.Point(457, 136);
            this.txtProducao.Name = "txtProducao";
            this.txtProducao.Size = new System.Drawing.Size(100, 20);
            this.txtProducao.TabIndex = 16;
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(457, 165);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(100, 20);
            this.txtSalario.TabIndex = 17;
            // 
            // txtGratificacao
            // 
            this.txtGratificacao.Location = new System.Drawing.Point(457, 194);
            this.txtGratificacao.Name = "txtGratificacao";
            this.txtGratificacao.Size = new System.Drawing.Size(100, 20);
            this.txtGratificacao.TabIndex = 18;
            // 
            // txtCargo
            // 
            this.txtCargo.Location = new System.Drawing.Point(457, 86);
            this.txtCargo.Name = "txtCargo";
            this.txtCargo.Size = new System.Drawing.Size(100, 20);
            this.txtCargo.TabIndex = 19;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(457, 61);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 20;
            // 
            // txtSalarioBruto
            // 
            this.txtSalarioBruto.Location = new System.Drawing.Point(457, 273);
            this.txtSalarioBruto.Name = "txtSalarioBruto";
            this.txtSalarioBruto.Size = new System.Drawing.Size(100, 20);
            this.txtSalarioBruto.TabIndex = 21;
            this.txtSalarioBruto.TextChanged += new System.EventHandler(this.txtSalarioBruto_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtSalarioBruto);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtCargo);
            this.Controls.Add(this.txtGratificacao);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtProducao);
            this.Controls.Add(this.txtNumeroInscricao);
            this.Controls.Add(this.lblSalarioBruto);
            this.Controls.Add(this.lblGratificação);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.lblProdução);
            this.Controls.Add(this.lblNumeroInscricao);
            this.Controls.Add(this.lblCargo);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.btnPalindromo);
            this.Controls.Add(this.btnNumeroH);
            this.Controls.Add(this.lblNumeroN);
            this.Controls.Add(this.txtNumeroN);
            this.Controls.Add(this.btnNumeroPares);
            this.Controls.Add(this.btnNumeroR);
            this.Controls.Add(this.btnNumeroBranco);
            this.Controls.Add(this.rchbxTexto);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchbxTexto;
        private System.Windows.Forms.Button btnNumeroBranco;
        private System.Windows.Forms.Button btnNumeroR;
        private System.Windows.Forms.Button btnNumeroPares;
        private System.Windows.Forms.TextBox txtNumeroN;
        private System.Windows.Forms.Label lblNumeroN;
        private System.Windows.Forms.Button btnNumeroH;
        private System.Windows.Forms.Button btnPalindromo;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblCargo;
        private System.Windows.Forms.Label lblNumeroInscricao;
        private System.Windows.Forms.Label lblProdução;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.Label lblGratificação;
        private System.Windows.Forms.Label lblSalarioBruto;
        private System.Windows.Forms.TextBox txtNumeroInscricao;
        private System.Windows.Forms.TextBox txtProducao;
        private System.Windows.Forms.MaskedTextBox txtSalario;
        private System.Windows.Forms.MaskedTextBox txtGratificacao;
        private System.Windows.Forms.TextBox txtCargo;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalarioBruto;
    }
}

