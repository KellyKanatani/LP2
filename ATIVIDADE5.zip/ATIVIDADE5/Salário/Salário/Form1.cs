﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Salário
{
    public partial class Form1 : Form
    {
        private void btnDesconto_Click(object sender, EventArgs e)
        {
            string Dados;
            double SalarioBruto, AliquotaINSS, AliquotaIRPF, SalarioFamilia, SalarioLiquido, DescontoINSS, DescontoIRPF, Nome, NumeroFilhos;

            if ((double.TryParse(mskbxSalarioBruto.Text, out SalarioBruto)) &&
                (double.TryParse(mskbxAliquotaINSS.Text, out AliquotaINSS)) &&
                (double.TryParse(mskbxAliquotaIRPF.Text, out AliquotaIRPF)) &&
                (double.TryParse(mskbxSalarioFamilia.Text, out SalarioFamilia)) &&
                (double.TryParse(mskbxSalarioLiquido.Text, out SalarioLiquido)) &&
                (double.TryParse(mskbxDescontoINSS.Text, out DescontoINSS)) &&
                (double.TryParse(mskbxDescontoIRPF.Text, out DescontoIRPF)) &&
                (double.TryParse(mskbxNome.Text, out Nome)) &&
                (double.TryParse(mskbxNumeroFilhos.Text, out NumeroFilhos)))
            {
                //Aliquota INSS
                if (SalarioBruto <= 800.47)
                    AliquotaINSS = 7.65;
                if (SalarioBruto > 800.47 && SalarioBruto <= 1050)
                    AliquotaINSS = 8.65;
                if (SalarioBruto > 1050 && SalarioBruto <= 1400.77)
                    AliquotaINSS = 9.00;
                if (SalarioBruto > 1400.77 && SalarioBruto <= 2801.56)
                    AliquotaINSS = 11.00;
                if (SalarioBruto > 2801.56)
                    AliquotaINSS = 308.17;
                if (SalarioBruto <= 2801.56)
                    MessageBox.Show(AliquotaINSS + "%");
                if (SalarioBruto > 2801.56)
                    MessageBox.Show("R$" + AliquotaINSS);

                //Aliquota IRPF
                if (SalarioBruto <= 1257.12)
                    AliquotaIRPF = 0;
                if (SalarioBruto > 1257.12 && SalarioBruto <= 2512.08)
                    AliquotaIRPF = 15.00;
                if (SalarioBruto > 2512.08)
                    AliquotaIRPF = 27.5;

                //Salário Família
                if (SalarioBruto <= 435.52)
                    SalarioFamilia = NumeroFilhos * 22.33;
                if (SalarioBruto > 435.52 && SalarioBruto <= 654.61)
                    SalarioFamilia = NumeroFilhos * 15.74;
                if (SalarioBruto > 654.61)
                    SalarioFamilia = 0;

                //Desconto INSS
                DescontoINSS = SalarioBruto * (AliquotaINSS / 100);

                //Desconto IRPF
                DescontoIRPF = SalarioBruto * (AliquotaIRPF / 100);

                //Salário Líquido
                SalarioLiquido = SalarioBruto + SalarioFamilia - DescontoINSS - DescontoIRPF;

                //Dados 
                if (rbtnFeminino.Checked)
                {
                    if (ckbxCasado.Checked)
                    {
                        Dados = "Os descontos do salário do sr(a). " + mskbxNome + " que é casado(a) e que tem " + mskbxNumeroFilhos + " filho(s) são:";
                        txtDados.Text = Dados.ToString();
                    }
                }
            }
        }
    }
}
