﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MenusMétodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }
        int Numero1, Numero2;

        private void btnSortear_Click(object sender, EventArgs e)
        {
            if ((int.TryParse(txtNumero1.Text, out Numero1)) &&
                (int.TryParse(txtNumero2.Text, out Numero2)))
            if (Numero1 > Numero2)
            {
                    Random random = new Random();
                    double r = random.Next(Numero2, Numero1);
                    MessageBox.Show(r.ToString());
             }
            if (Numero1 < Numero2)
            {
                Random random = new Random();
                double r = random.Next(Numero1, Numero2);
                MessageBox.Show(r.ToString());
            }
            else
                MessageBox.Show("Digite números distintos!!!");
        }
    }
}
