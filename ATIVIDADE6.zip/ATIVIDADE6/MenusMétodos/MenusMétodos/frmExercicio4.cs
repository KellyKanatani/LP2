﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MenusMétodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumeroCaracteres_Click(object sender, EventArgs e)
        {
            int contador = 0;
            for (var i = 0; i < rchTexto.Text.Length; i++)
                if (char.IsNumber(rchTexto.Text[i]))
                    contador += 1;
            MessageBox.Show("Quantidade de numeros: " + contador);
        }

        private void btnCaracterBranco_Click(object sender, EventArgs e)
        {
            int cont;
            for (cont = 0; cont < 100; cont++)
            {
                if (Char.IsWhiteSpace(rchTexto.Text, cont))
                {
                    MessageBox.Show("O primeiro espaço em branco fica na posição: " + (cont+1));
                    break;
                }
            }
        }

        private void btnNumeroCaracteresAlfabeticos_Click(object sender, EventArgs e)
        {
            int cont;
            cont = 0;
            foreach (char caracter in rchTexto.Text)
            {
                if (Char.IsLetter(caracter))
                cont = cont + 1;
            }
            MessageBox.Show("A quantidade de caracteres é: " + cont);
        }
    }
}
