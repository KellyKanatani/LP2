﻿namespace MenusMétodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchTexto = new System.Windows.Forms.RichTextBox();
            this.btnNumeroCaracteres = new System.Windows.Forms.Button();
            this.btnCaracterBranco = new System.Windows.Forms.Button();
            this.btnNumeroCaracteresAlfabeticos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchTexto
            // 
            this.rchTexto.AcceptsTab = true;
            this.rchTexto.Location = new System.Drawing.Point(178, 67);
            this.rchTexto.Name = "rchTexto";
            this.rchTexto.Size = new System.Drawing.Size(441, 101);
            this.rchTexto.TabIndex = 0;
            this.rchTexto.Text = "";
            // 
            // btnNumeroCaracteres
            // 
            this.btnNumeroCaracteres.Location = new System.Drawing.Point(178, 204);
            this.btnNumeroCaracteres.Name = "btnNumeroCaracteres";
            this.btnNumeroCaracteres.Size = new System.Drawing.Size(134, 24);
            this.btnNumeroCaracteres.TabIndex = 1;
            this.btnNumeroCaracteres.Text = "Número de Caracteres";
            this.btnNumeroCaracteres.UseVisualStyleBackColor = true;
            this.btnNumeroCaracteres.Click += new System.EventHandler(this.btnNumeroCaracteres_Click);
            // 
            // btnCaracterBranco
            // 
            this.btnCaracterBranco.Location = new System.Drawing.Point(331, 204);
            this.btnCaracterBranco.Name = "btnCaracterBranco";
            this.btnCaracterBranco.Size = new System.Drawing.Size(134, 23);
            this.btnCaracterBranco.TabIndex = 2;
            this.btnCaracterBranco.Text = "Primeiro Caracter em Branco";
            this.btnCaracterBranco.UseVisualStyleBackColor = true;
            this.btnCaracterBranco.Click += new System.EventHandler(this.btnCaracterBranco_Click);
            // 
            // btnNumeroCaracteresAlfabeticos
            // 
            this.btnNumeroCaracteresAlfabeticos.Location = new System.Drawing.Point(485, 204);
            this.btnNumeroCaracteresAlfabeticos.Name = "btnNumeroCaracteresAlfabeticos";
            this.btnNumeroCaracteresAlfabeticos.Size = new System.Drawing.Size(134, 23);
            this.btnNumeroCaracteresAlfabeticos.TabIndex = 3;
            this.btnNumeroCaracteresAlfabeticos.Text = "Número de Caracteres Alfabéticos";
            this.btnNumeroCaracteresAlfabeticos.UseVisualStyleBackColor = true;
            this.btnNumeroCaracteresAlfabeticos.Click += new System.EventHandler(this.btnNumeroCaracteresAlfabeticos_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnNumeroCaracteresAlfabeticos);
            this.Controls.Add(this.btnCaracterBranco);
            this.Controls.Add(this.btnNumeroCaracteres);
            this.Controls.Add(this.rchTexto);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchTexto;
        private System.Windows.Forms.Button btnNumeroCaracteres;
        private System.Windows.Forms.Button btnCaracterBranco;
        private System.Windows.Forms.Button btnNumeroCaracteresAlfabeticos;
    }
}