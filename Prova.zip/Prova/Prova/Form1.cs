﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Prova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string ra;

            ra = Interaction.InputBox("RA: P");

            string num = ra.Substring(ra.Length - 1, 1);

            int ultNum = Int32.Parse(num);

            if (ultNum == 0)
            {
                double[,] vendas = new double[10, 4];
                int i, j;
                string aux;
                double[] totalMes = new double[10];
                double totalGeral, aux2 = 0, aux3 = 0;
                for (i = 0; i < 10; i++)
                {
                    for (j = 0; j < 4; j++)
                    {
                        aux = Interaction.InputBox("Total do mes " + (i+1).ToString() + ", semana " + (j+1).ToString() + ": R$"); 
                        vendas[i, j] = Convert.ToDouble(aux);
                        lstbxLoja.Text = ("Total do mes " + (i + 1).ToString() + ", semana " + (j + 1).ToString() + ": R$" + vendas[i,j]);
                        totalMes[i] = aux2 + vendas[i,j];
                        aux2 = totalMes[i];
                    }
                    lstbxLoja.Text = (">> Total Mês R$" + totalMes[i]);
                    lstbxLoja.Text = ("........................");
                    totalGeral = aux3 + totalMes[i];
                    aux3 = totalGeral;
                }
                lstbxLoja.Text = (">> Total Geral R$" + aux3);
                lstbxLoja.Text = ("........................");
            }
            if (ultNum != 0)
            {
                double[,] vendas = new double[ultNum, 4];
                int i, j;
                string aux;
                double[] totalMes = new double[ultNum];
                double totalGeral, aux2 = 0, aux3 = 0;
                for (i = 0; i < ultNum; i++)
                {
                    for (j = 0; j < 4; j++)
                    {
                        aux = Interaction.InputBox("Total do mes " + (i + 1).ToString() + ", semana " + (j + 1).ToString() + ": R$"); 
                        vendas[i, j] = Convert.ToDouble(aux);
                        lstbxLoja.Text = ("Total do mes " + (i + 1).ToString() + ", semana " + (j + 1).ToString() + ": R$" + vendas[i, j]);
                        totalMes[i] = aux2 + vendas[i, j];
                        aux2 = totalMes[i];
                    }
                    lstbxLoja.Text = (">> Total Mês R$" + totalMes[i]);
                    lstbxLoja.Text = ("........................");
                    totalGeral = aux3 + totalMes[i];
                    aux3 = totalGeral;
                }
                lstbxLoja.Text = (">> Total Geral R$" + aux3);
                lstbxLoja.Text = ("........................");
            }
        }
    }
}
